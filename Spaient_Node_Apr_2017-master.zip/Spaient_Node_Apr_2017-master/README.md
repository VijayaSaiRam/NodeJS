# Spaient_Node_Apr_2017

Kindly run npm install for all the packages to installed locally or globally
