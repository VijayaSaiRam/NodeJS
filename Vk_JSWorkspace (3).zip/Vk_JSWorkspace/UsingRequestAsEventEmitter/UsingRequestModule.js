//One way to call request method

/*var request=require('request');

request('http://www.google.com',function(error,response,body){

	console.log('error:',error);
	console.log('statuscode',response && response.statusCode);
	//console.log('body',body);
});
console.log("made the request");*/


//Another way of calling request method. override and give the name to method and call it
var request=require('request');
var fs=require('fs');

var s=request("http://www.google.com");


var response="";

//s is the instance of EventEmitter
s.on('data',function(chunkOfData){
 
//console.log("<<<<<<<<<<<<<<<<<<Data>>>>>>>>>>>>>>>>>>>>>\n\n\n"+chunkOfData);
response+=chunkOfData;                    //This is needed because chunkOfData is by default is bytes. so to convert into to string we have appended to response variable. so that we can write it to file
fs.writeFile('myresponse.html',response);
});

s.on('end',function(){
console.log("*************Ended- reading of file**************");
});

//fs.close();
/*
Here if we see we are not calling event.emit() explicitly as these are already handled in request module.   --- request is third party module installed using npm

https://github.com/request/request/blob/master/request.js 

refer the above link where we can see self.emit('data',chunk); self.emit('data', chunk) line : 1082
*/



/***** Another example on fs **/


var readableStream=fs.createReadStream('hello.txt');
var writableStream=fs.createWriteStream('output.txt');

readableStream.setEncoding('UTF-8');

var allData="";
process.nextTick(function(){

readableStream.on('data',function(chunk)
{
	allData+=chunk;

});
/**Here we are collecting the chunks of data and appending into to allData and once entire data is read , once it is ended , then we are writing the data to file**/
readableStream.on('end',function(){                 
console.log("wrriten:::::"+allData)
writableStream.write(allData);
});


});



/**Here we are collecting the chunks of data and appending into to allData and once entire data is read , once it is ended , then we are writing the data to file

Here we have managed everything ourselves. the same can be acheived using pipe; which avoids handling of data and end events.

Refer the following example

**/

var readableStream1=fs.createReadStream('hello.txt');    //Returns ReadStream object
var writableStream1=fs.createWriteStream('response.txt'); //Returns WriteStream object
 
readableStream1.setEncoding('UTF-8');


readableStream1.pipe(writableStream1);     //  The 'pipe' event is emitted when the stream.pipe() method is called on a readable stream, adding this writable to its set of destinations.



