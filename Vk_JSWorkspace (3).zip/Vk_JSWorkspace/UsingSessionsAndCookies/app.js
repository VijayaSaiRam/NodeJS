var express=require('express');

var session=require('express-session');
var cookieParser = require('cookie-parser')

var app=express();
var sessionData;
app.use(cookieParser());
app.use(session({
	secret:'Create a unique id',
	//cookie: { secure: true },
	saveUninitialized:false,
	resave:true



}));

app.get('/',function(request,response){

response.send('This is sessions and cookies management');
console.log(request.cookies);
console.log('----------------------------');
console.log(request.session);
sessionData=request.session;     // now var sessionData refers to request session 
sessionData.someSessionData="Actual vlaue !"; // setting session attribute

sessionData.save();
 
 console.log("some session data :::: "+sessionData.someSessionData);
});

app.get('/getData',function(request,response){

	console.log(request.session.someSessionData);
 	response.send("Response"+ sessionData.someSessionData);
});


app.listen(4000,function()
{

console.log('Server running @ 4000 !')
});