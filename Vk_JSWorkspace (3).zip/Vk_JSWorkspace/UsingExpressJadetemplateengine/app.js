var express=require('express');
var routes=require('./routes/index');
var path=require('path');
var app=express();

app.use('/',routes);
app.set('views',path.join(__dirname,'views'));
app.set('view engine','jade');        // refer the express documentation to refer the 
 

var bodyPaser=require('body-parser');                //If we send the data as post request then we need body-parser to parse the data

/*var products=[{Name:'Laptop',Price:45000},{Name:'Mobile',Price:15000}];

router.route('/products/:pathvariable').get(function(request,response){

var id=request.query.id;
var name=request.query.name;
var pathvar=request.param.pathvariable;  //method to get the path variables

console.log("path variable is"+pathvar);
console.log("Id is"+id);
console.log("name is"+name);

	if(name=='Laptop')
	{

		response.json(products[0]);
	}

	else if(name=='Mobile')
	{
			response.json(products[1]);

	}


});

app.use('/data',router); */
/*app.use(bodyPaser.urlencoded({extended:true}));   // to read the data as key value pair , this is informing express that I am going to use body-parser of node js

app.get('/',function(request,response){

	response.sendFile('login.html',{root:__dirname});

});


app.post('/login', function(request,response){


	var uname=request.body.username;
	var pwd=request.body.password;


	console.log("User name :"+uname);
	console.log("Password is"+pwd);

	response.send("success");

});*/

app.listen(4000,function()
{

console.log('Server running @ 4000 !')


});



//1)Url to request is localhost:4000
//Then it displays the login form
// After entering the details and submitting it will execute the login method and sends the response.