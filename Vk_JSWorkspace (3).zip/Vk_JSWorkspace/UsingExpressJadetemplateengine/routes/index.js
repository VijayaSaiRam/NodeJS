var express=require('express');

var router=express.Router();

router.get('/',function(req,res){
//rendering layout created by using jade templating engine
   res.render('index',
   {                       
	   data:'Jade Using Blocks',
	   msg:'This is displayed using Dynamic data',
	   users:[
	   	{Name:'Vijaya'},
	   	{Name:'Sairam'},
	   	{Name:'Gopal'}
	   ]

});

});

module.exports=router;

