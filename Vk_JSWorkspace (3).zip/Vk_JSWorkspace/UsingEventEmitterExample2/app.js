//Example with setInterval and event emitters

var EventEmitter=require('events').EventEmitter;    

var getResource=function(maxIteration){
	var e=new EventEmitter();
	//emit events here

	process.nextTick(function()
	{
		 var count=0;
		 e.emit('start');   // By the time this event is emitted, this start event must be registered having listener


		 var t=setInterval(function(){

		 for(count;count<maxIteration;count++)
		 {

		 	e.emit('data',count); // By the time this event is emitted, this data event must be registered having listener

		 	if(count==8)
		 	{
		 		e.emit('error',count);
		 		clearInterval(t);
		 	}
		 	
		 }
		 if(count==maxIteration)
		 {
		 	e.emit('done',count); // By the time this event is emitted, this done event must be registered having listener
		 		clearInterval(t);

		 }

		},1000);     

	});
	return e;
}



var res=getResource(10); //return an object of EventEmitter 

/*** Registering  events with their corresponding listeners ***/
res.on('start',function(){
	console.log("started.....");
});

res.on('data',function(d){
	console.log("I recieved :"+d)
});

res.on('done',function(d){
	console.log("I ended with count:"+d);
});
res.on('error',function(d){
	console.log("error occured at the count :"+d);
});