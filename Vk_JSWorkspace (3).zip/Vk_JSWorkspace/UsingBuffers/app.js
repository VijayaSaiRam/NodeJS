var buff=new Buffer('Sample data for buffer');

console.log(buff.toString());
console.log(buff.toString('utf-8'));

console.log(buff.toString('base64'));

var buff1=new Buffer(250);

var len=buff1

