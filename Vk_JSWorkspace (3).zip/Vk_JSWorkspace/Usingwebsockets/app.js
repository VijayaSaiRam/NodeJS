const http = require('http');

var fs=require('fs');

var socket=require('socket.io');

const hostname = '127.0.0.1';
const port = 3000;

const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/html');
  //res.end('<h1>Hello World</h1>\n');

  fs.readFile(__dirname+'/messageinput.html',function(error,data){


  	if(error)
  	{

  		console.log("Error occured :"+error);
  	}

  	else
  	{

  		res.writeHead(200,{'Content-Type':'text/html'});
  		return res.end(data);
  	}
  });


});


var io=socket.listen(server);
io.sockets.on('connection',function(skt)
{
    setInterval(function(){

      var dataToBeSent = new Date();
      skt.emit('messageForClient',dataToBeSent);
    },2000);

    skt.on('messageFromClient',function(data)
  {
    console.log("message is "+data);
  });


});



server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});