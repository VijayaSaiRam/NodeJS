/**  
This is the source file and this comment would not appear in minified file
**/

var boolValue=false;
var numVariable=100;
var strVariable="Hello Gulp";
function Add(veryLongX, veryLongY)
{

	return veryLongX+veryLongY;
}
