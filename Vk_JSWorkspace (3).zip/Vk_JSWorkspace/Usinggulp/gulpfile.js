var gulp=require('gulp');

var minify=require('gulp-minify');

/*gulp.task('default', function(){

console.log("Gulp ran the default task");

return gulp.src("source/*").pipe(minify()).pipe(gulp.dest("./target"))                  //gulp.src("Source/*")  It internally returns readable stream, after piping minification is performed then wrritten in target folder
});*/


gulp.task('minifyjs', function(){

console.log("Gulp ran the default task");

return gulp.src("source/*").pipe(minify()).pipe(gulp.dest("./target"))                 


});