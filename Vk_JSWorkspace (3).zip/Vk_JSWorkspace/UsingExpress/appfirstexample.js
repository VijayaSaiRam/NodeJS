var express=require('express');

var app=express();

app.get('/',function(request,response){


  var products=[
   {Name:'laptop',Price:30000},
   {Name:'Mobile',Price:10000}


  ];
	//response.send('Welcome to Express !'); // simple text response
	//response.sendFile('client.html',{root:__dirname});   // to send file as response

	response.json(products);     //response json ---- all these methods present in response object of express.
})



app.listen(4000,function()
{

console.log('Server running @ 4000 !')
});