var express=require('express');

var app=express();


var router=express.Router();

var products=[{Name:'Laptop',Price:45000},{Name:'Mobile',Price:15000}];

router.route('/products/:pathvariable').get(function(request,response){

var id=request.query.id;
var name=request.query.name;
var pathvar=request.param.pathvariable;  //method to get the path variables

console.log("path variable is"+pathvar);
console.log("Id is"+id);
console.log("name is"+name);
	if(name=='Laptop')
	{

		response.json(products[0]);
	}

	else if(name=='Mobile')
	{
			response.json(products[1]);

	}


});

app.use('/data',router);

app.get('/',function(request,response){

	
});



app.listen(4000,function()
{

console.log('Server running @ 4000 !')
});



//url to request is http://localhost:4000/data/products/productinfo?id=40&name=Mobile
//url to request is http://localhost:4000/data/products/productinfo?id=40&name=Mobile