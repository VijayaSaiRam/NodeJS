var nettcp=require('net');

var fs=require('fs');

var writableLog=fs.createWriteStream("logs.txt");
var server=nettcp.createServer(function(connect){

console.log("Connection established*************");

	connect.on('end',function(){

  		console.log("Connection terminated");

 	});


 	connect.write("Some default message");

 	connect.pipe(connect); //connect is duplex stream where as Stream is not. so In case of connect to read and write we use the same connect object.This displays on telnet it self

 	//If we want to write something to file

 	connect.pipe(connect).pipe(writableLog);

 	
 	});

    server.listen(6565,function(){

 		console.log("Server listening @ 6565");

});



 //to see the output >node app
 // then open telnet and type the command open localhost 6565
 // then connection will be established to the server

 //Make sure that on controlpanel-->Programs and Features-->Telnet is checked