var mathLib=require('./Mathlib');
console.log(mathLib.Addition(10,20));
console.log(mathLib.Multiplication(10,20));
