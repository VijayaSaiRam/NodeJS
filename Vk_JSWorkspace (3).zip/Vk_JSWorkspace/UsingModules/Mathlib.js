var Add=function(x,y){

	return x+y;
}

var Subtract=function(x,y)
{
	return x-y;
}
var multiply=function(x,y)
{

	return x*y;
}
var divide=function(x,y)
{
	return (x/y);
}

module.exports.Addition=Add;					//Exporting Add method to outside world
module.exports.Multiplication=multiply;			//Exporting multiply method to outside world


//Another way of exporting ---creating exports object


module.exports={

Addition:Add,
Multiplication:multiply
};


