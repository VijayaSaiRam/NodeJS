//One way to call request method

/*var request=require('request');

request('http://www.google.com',function(error,response,body){

	console.log('error:',error);
	console.log('statuscode',response && response.statusCode);
	//console.log('body',body);
});
console.log("made the request");*/


//Another way of calling request method. override and give the name to method and call it
var request=require('request');
var callBack=function(error,response,body){

	console.log('error:',error);
	console.log('statuscode',response && response.statusCode);
	//console.log('body',body);
}

request("http://www.google.com",callBack);
console.log("made the request");
