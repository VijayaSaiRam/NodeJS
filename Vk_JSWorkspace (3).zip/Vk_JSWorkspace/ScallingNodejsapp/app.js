var exec=require('child_process').exec;

//returns stream
var child=exec('node -v',null,function(err,stdout,stderr){              

if(err)
{

	console.log('Error is :'+err);
}
else
{

	console.log('The result :'+stdout);
}

});

/*
It creates the child process and executes and returns whatever is there in the stream. then returns to the parent process then ends
*/

exec('systeminfo',null,function(err,stdout,stderr){


	if(err)
	{

		console.log("Error is "+err);
	}

	else
	{

		console.log("The result is "+stdout);
	}
});