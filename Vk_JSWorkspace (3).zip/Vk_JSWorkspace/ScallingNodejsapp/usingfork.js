var childProcess=require('child_process');

var workerProcess;


for(var i=0;i<3;i++)
{

	workerProcess=childProcess.fork('myModule',[i]);
}