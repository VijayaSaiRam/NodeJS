var childProcess=require('child_process');

 var workerProcess;

 for(var i=0;i<3;i++)
 {

 	workerProcess=childProcess.spawn('node',['myModule',i]);
 	workerProcess.stdout.on('data',function(data){
 	console.log("Data from the child"+data);

 	});

 	workerProcess.on('close',function(code){
	console.log("worker process exited with the code"+code);	

 	});
 }