console.log('Child process id is'+process.pid);
console.log('Executed process'+process.argv[2]);

