var EventEmitter=require('events').EventEmitter;    

var getResource=function(maxIteration){
	var e=new EventEmitter();
	//emit events here

	process.nextTick(function()
	{
		 var count=0;
		 e.emit('start');   // By the time this event is emitted, this start event must be registered having listener

		 for(count;count<maxIteration;count++)
		 {

		 	e.emit('data',count); // By the time this event is emitted, this data event must be registered having listener

		 	if(count==8)
		 	{
		 		
		 	}
		 	
		 }

		 if(count==maxIteration)
		 {
		 	e.emit('done',count); // By the time this event is emitted, this done event must be registered having listener

		 }

	});
	return e;
}



var res=getResource(10); //return an object of EventEmitter 

/*** Registering  events with their corresponding listeners ***/
res.on('start',function(){
	console.log("started.....");
});

res.on('data',function(d){
	console.log("I recieved :"+d)
});

res.on('done',function(d){
	console.log("I ended with count:"+d);
});
