var fs=require('fs');


fs.mkdirSync('temp');   //create the directory with this name - synchronous version of mkdir
if(fs.existsSync('temp'))  //checks whether file exists or not. returns true if exists
{

	process.chdir('temp');
	fs.writeFileSync('test.txt','This is some sample data to be written !');
	fs.renameSync('test.txt','new.txt');
	console.log('File has a size of :'+fs.statSync('new.txt').size +"bytes !");
	console.log('File contents:'+fs.readFileSync('new.txt').toString());
}

fs.mkdirSync('tempdir');   //create the directory with this name - synchronous version of mkdir
if(fs.existsSync('tempdir'))  //checks whether file exists or not. returns true if exists
{

    
	process.chdir('tempdir');
	fs.writeFileSync('test.txt','This is some sample data to be written !');
	fs.renameSync('test.txt','new.txt');
	console.log('File has a size of :'+fs.statSync('new.txt').size +"bytes !");
	console.log('File contents:'+fs.readFileSync('new.txt').toString());
}


console.log("Program ended..........");

