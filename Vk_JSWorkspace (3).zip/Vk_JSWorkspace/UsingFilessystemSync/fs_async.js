var fs=require('fs');

fs.mkdir('tempasync',function(err)
{

	if(err)
	{

		console.log("Error thrown"+err);
	}

	else
	{

		fs.exists('tempasync',function(exists){

			if(exists)
			{

				process.chdir('tempasync');

				fs.writeFile('test.txt',"This is sample text for file async");
				if(fs.exists('test.txt'))
				{
				fs.rename('test.txt','new.txt', function(err){
					console.log(err);
					fs.stat('new.txt',function(err,stats){
						console.log("file has size of "+stats.size+"bytes !");
						fs.readFile('new.txt',function(err,data){
								console.log("file contents are"+data.toString());
						});

				});


				});
			}
			}

		});
	}
});



//here test.txt is not renamed to new.txt as it is async, by the time it is created, remaining executed at that time test.txt is not there