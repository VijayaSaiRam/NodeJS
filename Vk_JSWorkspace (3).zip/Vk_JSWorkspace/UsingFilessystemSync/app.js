var fs=require('fs');

if(fs.existsSync('temp'))
{

	console.log("Dir exists ... removing");

	if(fs.existsSync('temp/new.txt'))
	{

		fs.unlinkSync('temp/new.txt');
	}
	fs.rmdirSync('temp');
}


if(fs.existsSync('tempdir'))
{
 console.log("inside if");
	var files=fs.readdirSync('tempdir');

	files.forEach((file) => {

		console.log("name of the file is"+file);
		fs.unlinkSync('tempdir'+"/"+file);

			}
		);

	fs.rmdirSync('tempdir');
}


/*fs.mkdirSync('temp');   //create the directory with this name - synchronous version of mkdir
if(fs.existsSync('temp'))  //checks whether file exists or not. returns true if exists
{

	process.chdir('temp');
	fs.writeFileSync('test.txt','This is some sample data to be written !');
	fs.renameSync('test.txt','new.txt');
	console.log('File has a size of :'+fs.statSync('new.txt').size +"bytes !");
	console.log('File contents:'+fs.readFileSync('new.txt').toString());
}*/

console.log("Program ended..........");

