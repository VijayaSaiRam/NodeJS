var fs=require('fs');

fs.readFile('data.txt',function(error,dataFromTheFile){

	if(error)
	{
		console.log("Error occured:"+error);
	}
	else
	{
		console.log('Reading (Async) Result:'+dataFromTheFile);
	}

});