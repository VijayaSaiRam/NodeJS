var path = require("path");

console.log(`Rock on World from ${path.basename(__filename)}`);
